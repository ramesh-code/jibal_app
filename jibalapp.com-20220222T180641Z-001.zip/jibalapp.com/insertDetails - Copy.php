<?php

$username = "root";
$password = "admin";
$hostname = "localhost";
//"?imei_no=2431243123&app_id=jibalapp.com&first_name=Tushar&last_name=Tyagi&email=tushar@gmail.com&mobile_no=909090923&dob=&";
if (!empty($_GET['imei_no']) && !empty($_GET['app_id']) && !empty($_GET['first_name']) && !empty($_GET['email']) && !empty($_GET['mobile_no'])) {

    $imeino = $_GET['imei_no'];
    $app_id = $_GET['app_id'];
    $first_name = $_GET['first_name'];
    $last_name = $_GET['last_name'];
    $email = $_GET['email'];
    $mobile_no = $_GET['mobile_no'];
    $dob = $_GET['dob'];
    $entry_date = date('y-m-dd');

    $query = "SELECT * from tblgiftuser WHERE imei_no='$imeino' and gid='' LIMIT 0,1";
    $result = mysql_query($query) or die(mysql_error());
    if ($result) {
        echo "{\"status\":false,\"message\":\"You have already registered.\"}";
    } else {
        $query = " INSERT INTO tblgiftuser(gid,imei_no,app_id,first_name,last_name,email,mobile_no,dob,entry_date) ";
        $query .= " VALUES('1','$imeino','$app_id','$first_name','$last_name','$email','$mobile_no','$dob','$entry_date') ";
        $result = mysql_query($query);
        if ($result) {
            $uid = mysql_insert_id();
            echo "{\"status\":true,\"message\":\"Thank you for registering.\"}";
        }
    }
} else {
    echo "{\"status\":false,\"message\":\"Please fill are the mandatory fields.\"}";
}