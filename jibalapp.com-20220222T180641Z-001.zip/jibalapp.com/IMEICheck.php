<?php
$username = "root";
$password = "admin";
$hostname = "localhost"; 
if(!empty($_GET['imeicode'])){
$IMECode = $_GET['imeicode'];

//connection to the database
$dbhandle = mysql_connect($hostname, $username, $password)
 or die("Unable to connect to MySQL");

//select a database to work with
$selected = mysql_select_db("jibalapp",$dbhandle)
  or die("Could not select jibalapp databse");

//execute the SQL query and return records
$result = mysql_query("SELECT * FROM `tblgiftuser` WHERE `imei_no`=$IMECode  LIMIT 0 , 1");

$resP_IMEI="";
$resP_DateOut="";
$resP_DateExp="";
//fetch tha data from the database
while ($row = mysql_fetch_array($result)) {
	$resP_IMEI=$row["imei_no"];	

	break;	
}  	
if(!empty($resP_IMEI)){
   	echo "{\"status\":true,\"message\":\"This is valid IMEI Code\",\"data\":{\"IMEICode\":\"".$resP_IMEI."\"}}";
       }
       else{
          	echo "{\"status\":false,\"message\":\"This is invalid IMECode: ".$resP_IMEI."\",\"data\":null}";
       }
//close the connection
mysql_close($dbhandle);
}
else{
	echo "{\"status\":false,\"message\":\"This is invalid access.The requested query is either null or empty.\",\"data\":null}";
}
?>