<?php

$username = "root";
$password = "admin";
$hostname = "localhost";

$dbhandle = mysql_connect($hostname, $username, $password) or die("Unable to connect to MySQL");

//select a database to work with
$selected = mysql_select_db("jibalapp", $dbhandle) or die("Could not select databse");

//execute the SQL query and return records
$result = mysql_query(" SELECT count( * ) AS 'Count' FROM `tblgift` WHERE STATUS =1 LIMIT 0 , 1");
$resP_IMEI = "";
$resP_DateOut = "";
$resP_DateExp = "";
$row = mysql_fetch_row($result);
if ($row) {
    if ($row[0] > 0) {
        echo "{\"status\":true,\"message\":\"Gift registration available.\"}";
    }
} else {
    echo "{\"status\":false,\"message\":\"Gift registration is not available.\"}";
}
mysql_close($dbhandle);
?>