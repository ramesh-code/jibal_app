<?php
$username = "root";
$password = "";
$hostname = "localhost";
$dbhandle = mysql_connect($hostname, $username, $password) or die("Unable to connect to MySQL");
//select a database to work with
$selected = mysql_select_db("jibalapp", $dbhandle) or die("Could not select databse");

if (!empty($_GET['imei_no']) && !empty($_GET['app_id']) && !empty($_GET['first_name']) && !empty($_GET['email']) && !empty($_GET['mobile_no'])) {
    $imeino = $_GET['imei_no'];
    $app_id = $_GET['app_id'];
    $first_name = $_GET['first_name'];
    $last_name = $_GET['last_name'];
    $email = $_GET['email'];
    $mobile_no = $_GET['mobile_no'];
    if(isset($_GET['dob']))
    $dob = $_GET['dob'];
    $entry_date = date('Y-m-d');
	
	     $gid_query = "SELECT gid from tblgift WHERE status='1' LIMIT 0,1";
     $gid_result = mysql_query($gid_query) or die(mysql_error());
     $gidvalue = mysql_fetch_row($gid_result);
     $gid = $gidvalue['0'];
     

    $query = "SELECT * from tblgiftuser WHERE imei_no='$imeino' and gid='$gid' LIMIT 0,1";
    $query_result = mysql_query($query) or die(mysql_error());
	$result = mysql_fetch_row($query_result);

    if ($result) {
        echo "{\"status\":false,\"message\":\"You have already registered.\"}";
    } else {
        $query = " INSERT INTO tblgiftuser(gid,imei_no,app_id,first_name,last_name,email,mobile_no,dob,entry_date) ";
        $query .= " VALUES('$gid','$imeino','$app_id','$first_name','$last_name','$email','$mobile_no','$dob','$entry_date') ";
        $result = mysql_query($query) or die(mysql_error());
        if ($result) {
            echo "{\"status\":true,\"message\":\"Thank you for registering.\"}";
        }
    }
} else {
    echo "{\"status\":false,\"message\":\"Please fill all the mandatory fields.\"}";
}