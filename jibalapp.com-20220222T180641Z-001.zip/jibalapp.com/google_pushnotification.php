<?php
ini_set('display_errors',1);
?>
<form name="from_push_notif" id="from_push_notif" method="post" action="google_pushnotification.php">
Registration Id : <input type="text" name="reg_key" id="reg_key" size="100" value="<?php echo trim($_POST['reg_key']); ?>"><br/><br/>
API Key : <input type="text" name="api_key" id="api_key" size="100" value="<?php echo trim($_POST['api_key']); ?>"><br/><br/>
Message : <input type="text" name="msg" id="msg" size="100" value="<?php echo trim($_POST['msg']); ?>"><br/><br/>
<input type="submit" name="submit" id="submit" value="Send">
</form>
<?php
if(isset($_POST['reg_key']))
{
	$regid_array=array();
	
	$messageText = '';
	array_push($regid_array,trim($_POST['reg_key']));
	
	$regid_cnt=count($regid_array);
			
	if($regid_cnt > 0)
	{
		//$headers = array("Content-Type:"."application/json", "Authorization:"."key=" . "AIzaSyBBKG4Ah-ok1aLdLqWENiCt27gdb5Hok-g");
		$headers = array("Content-Type:"."application/json", "Authorization:"."key=" . "".trim($_POST['api_key'])."");
		$data = array(
			'collapse_key' => 'new'.time(),
			'data' => array('payload' => trim($_POST['msg'])),
			'registration_ids' => $regid_array
		);
		//print_r($data);
		$ch = curl_init();
		//echo '<br/><br/>';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); 
		curl_setopt($ch, CURLOPT_URL, "https://android.googleapis.com/gcm/send");
		curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
		error_log(json_encode($data));
		$response = curl_exec($ch);
		print_r($response);
		echo '<br/><br/>';
		$resparray=json_decode($response);
		print_r($resparray);
		/*i$i=0;
		
		f($resparray->canonical_ids > 0)
		{
			foreach($resparray->results as $value)
			{
				if(isset($value->message_id))
				{
					if(isset($value->registration_id))
					{
						$this->users_model->update_registration_id($regid_array[$i],$value->registration_id);
					}
				}
				$i++;
			}
		}*/
		
		curl_close($ch);
		error_log($response);
	}
}
?>
