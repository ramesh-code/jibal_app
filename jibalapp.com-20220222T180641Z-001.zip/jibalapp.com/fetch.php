<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$username = "root";
$password = "";
$hostname = "localhost";
$dbhandle = mysql_connect($hostname, $username, $password) or die("Unable to connect to MySQL");
//select a database to work with
$selected = mysql_select_db("secure_a6fr", $dbhandle) or die("Could not select databse");
  $query = "SELECT * from tblgiftuser";
    $query_result = mysql_query($query) or die(mysql_error());

while($row = mysql_fetch_assoc($query_result))
    {           
          $data [] = $row['first_name'];    
          $data [] = $row['last_name'];
      
          
        
            
        }
        echo "<pre>";
        print_r($row); 
        echo "</pre>";
    mysql_close();
    $username = "root";
$password = "";
$hostname = "localhost";
$dbhandle = mysql_connect($hostname, $username, $password) or die("Unable to connect to MySQL");
mysql_query("SET NAMES 'utf8'");//chnages by ramesh
mysql_query("SHOW VARIABLES LIKE 'character_set_%'");//cahnges by ramesh
foreach($data as $key=>$value){
    $fnam = trim($value);
    print_r($value);
             $query = " INSERT INTO tblgiftuser2(first_name) ";
        $query .= " VALUES('$fnam') ";
        $result = mysql_query($query) or die(mysql_error());
}

