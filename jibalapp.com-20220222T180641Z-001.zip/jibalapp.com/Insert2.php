<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $username = "root";
        $password = "admin";
        $hostname = "localhost";
        $dbhandle = mysql_connect($hostname, $username, $password) or die("Unable to connect to MySQL");
        //select a database to work with
        $selected = mysql_select_db("jibalapp", $dbhandle) or die("Could not select databse");

        $url = $_SERVER['QUERY_STRING'];
        $str = html_entity_decode($url, null, 'UTF-8');
        parse_str($str, $output);

        if (!empty($output['imei_no']) && !empty($output['app_id']) && !empty($output['first_name']) && !empty($output['email']) && !empty($output['mobile_no'])) {
            $entry_date = date('Y-m-d');
            
            $imeino = $output['imei_no'];
            $app_id = $output['app_id'];
            $first_name = $output['first_name'];
            $last_name = $output['last_name'];
            $email = $output['email'];
            $mobile_no = $output['mobile_no'];
            $dob = $output['dob'];
            $gid_query = "SELECT gid from tblgift WHERE status='1' LIMIT 0,1";
            $gid_result = mysql_query($gid_query) or die(mysql_error());
            $gidvalue = mysql_fetch_row($gid_result);
            $gid = $gidvalue['0'];

            $query = "SELECT * from tblgiftuser WHERE imei_no='$imeino' and gid='$gid' LIMIT 0,1";
            $query_result = mysql_query($query) or die(mysql_error());
            $result = mysql_fetch_row($query_result);

            if ($result) {
                echo "{\"status\":false,\"message\":\"You have already registered.\"}";
            } else {                
                $query = " INSERT INTO tblgiftuser(gid,imei_no,app_id,first_name,last_name,email,mobile_no,dob,entry_date) ";
                $query .= " VALUES('$gid','$imeino','$app_id','$first_name',_utf8'$last_name','$email','$mobile_no','$dob','$entry_date') ";
                echo $query;
                $result = mysql_query($query) or die(mysql_error());
                if ($result) {
                    echo "{\"status\":true,\"message\":\"Thank you for registering.\"}";
                }
            }
        } else {
            echo "{\"status\":false,\"message\":\"Please fill all the mandatory fields.\"}";
        }
        ?>
    </body>
</html>
