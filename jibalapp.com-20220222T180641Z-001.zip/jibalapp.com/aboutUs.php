<?php
//error_reporting(E_ALL);
include("config/configure.php");
include("config/database.php");
//include("includes/relativeTime.php");
db_connect();


db_query("SET NAMES utf8"); 
// pageid 	pagename 	pagedesc 	active 	createdon 	modifyon
$sql="SELECT * FROM tbmstPage WHERE pageid =1";
$query=db_query($sql);
$num=db_num_rows($query);
if($num > 0) // User exists in database then give all the users details for login 
{
	$row=db_fetch_array($query);
	$pagename=$row['pagename'];
	
	
	if(isset($_REQUEST['lng']))
	{
		if(trim($_REQUEST['lng'])=='ar')
		{
			$pagedesc=trim(stripslashes($row['pagedescar']));
		}
		else if(trim($_REQUEST['lng'])=='ku')
		{
			$pagedesc=trim(stripslashes($row['pagedescku']));
		}
		else
		{
			$pagedesc=trim(stripslashes($row['pagedesc']));
		}
	
	}
	else
	{
		$pagedesc=trim(stripslashes($row['pagedesc']));
	}
	
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
<title>Jibal Company</title>
 <link rel="icon"  type="image/png" href="img/fav3.png">
<style type="text/css">
body{
	
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	line-height:22px;
	color:#828381;}
h1{
	font-size:16px;
	padding:0px;
	margin:0px;
	}
img{
	margin:5px;
	}	
		
	
</style>
</head>
<body>
<!--<center><img src="images/jibal_splashlogo.png" width="200" height="86" /></center><br/>-->
<?=$pagedesc?>

 <!--<img src="images/1.png" width="180" height="127" align="left" />OpenText to Report Fourth Quarter and Fiscal Year 
JiBAL Information Technology was established in 2003, and become the authorized distributor for Samsung Mobile in Iraq<br><br>

<img src="images/2.png" width="180" height="127" align="right" />JiBAL is representing Samsung Mobile brand in Iraq, Samsung Mobile is a 
global leader and innovator in the worldwide mobile market, providing 
consumers with better mobile experiences through its smart technology 
and stylish handset designs.<br><br>

<img src="images/3.png" width="180" height="127" align="left" />JiBAL became a leader in the market through its qualified employees, 
resources and the know-how in the distribution industry, JiBAL employs 
over 100 persons in its own dedicated sales team as well as 
merchandizing, distribution and maintenance.-->
</body></html>